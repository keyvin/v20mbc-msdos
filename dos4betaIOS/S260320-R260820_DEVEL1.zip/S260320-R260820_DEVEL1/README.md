# A250220_DEVEL
Temporary development repo for the A250220 board (https://hackaday.io/project/170924)

**Development IOS Revision: S260320-R260820_DEVEL1** (see the Changelog inside the .ino file)

WARNING! This Revision is intended for development only.


In the **Examples** folder there are assembler source examples using IRQ.

NOTE: only the .ino file is changed. The others files are the same of the current public revision (S260320-R230520).

About the SD: for now use the same SD image of the current public revision.
